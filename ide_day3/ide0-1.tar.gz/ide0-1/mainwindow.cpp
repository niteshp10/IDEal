#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QProcess>
#include<QFileDialog>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButtonCompile_clicked()
{
    QProcess proc;
    proc.start("gcc --help");
    proc.waitForFinished();
    QByteArray result = proc.readAllStandardOutput();
    QByteArray error = proc.readAllStandardError();
    QString command1(result);
    QString command2(error);
    ui ->labelError->setText(command2);
}

void MainWindow::on_pushButtonRun_clicked()
{
    QProcess proc;
    proc.start("gcc --help");
    proc.waitForFinished();
    QByteArray result = proc.readAllStandardOutput();
    QString command1(result);
    ui ->textEditOutput->setText(command1);

    ui ->labelError->setText("");
}

void MainWindow::on_pushButtonBuild_clicked()
{
    QProcess proc;
    proc.start("gcc help");
    proc.waitForFinished();
    QByteArray error = proc.readAllStandardError();
    ui ->textEditOutput->setText("");
    QString command2(error);
    ui ->labelError->setText(command2);
}

void MainWindow::on_actionSave_triggered()
{
    QString fileName = QFileDialog::getSaveFileName(this,
         tr("Save File as ..."), "/home/pushkar", tr("C/C++ Files (*.c *.cpp)"));

    QFile file;
    file.setFileName(fileName);
    file.open(QIODevice::WriteOnly);
    QByteArray code;
    code.append(ui->textEditCoding->toPlainText());
    file.write(code);        // write to stderr
    file.close();
}

void MainWindow::on_actionOpen_triggered()
{
    QString fileName1 = QFileDialog::getOpenFileName(this,
         tr("Open File ..."), "/home/pushkar", tr("C/C++ Files (*.c *.cpp)"));

    QFile file;
    file.setFileName(fileName1);
    file.open(QIODevice::ReadOnly);
    QByteArray code;
    //file.read(fileName1);
   // code=file.write();
    //code.append(ui->textEditCoding);   //Error in this line
    file.write(code);        // write to stderr
    file.close();
}


void MainWindow::on_action_Exit_triggered()
{
    exit(0);
}
